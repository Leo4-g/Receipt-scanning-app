export interface User {
  id: string;
  name: string;
  email: string;
  userType: string;
}

export interface Document {
  id: string;
  title: string;
  amount: number;
  date: string;
  vendor: string;
  category: string;
  notes: string;
  status: string;
  userId: string;
  userName: string;
  userType: string;
  createdAt: string;
  imageUrl: string;
  thumbnailUrl: string;
}